import { StyleSheet } from "react-native/types";

export const styles = StyleSheet.create({
    container: {
      flexGrow: 1,      
    },
    camera:{
      flex: 1
    }
  });